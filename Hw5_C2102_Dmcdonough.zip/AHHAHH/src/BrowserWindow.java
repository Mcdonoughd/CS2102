
import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.util.LinkedList;

import org.junit.Test;

public class BrowserWindow {
	public static void main(String[] args) throws FileNotFoundException, UnsupportedFileExn {
		SearchEngine s = new SearchEngine(new LinkedList<String>());
		 s.screen();
	 }
}
