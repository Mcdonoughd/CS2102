import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Set;

import org.junit.Test;

 class QueryHashMap {
	 
	 QueryHashMap(){
 HashMap<String, LinkedList<Webpage>> Query = new HashMap<String, LinkedList<Webpage>>();
	 }
	 
private HashMap<String, LinkedList<Webpage>> Query = new HashMap<String, LinkedList<Webpage>>();

public LinkedList<Webpage> getquery(String query){
	return Query.get(query);
}

public  LinkedList<Webpage> addQuery(String query, LinkedList<Webpage> Match){
	Query.put(query, Match);
	return Match;
}

public boolean alreadySawQuery(String query) {
	for (String key : Query.keySet()) {
		   if(key.equals(query)){
			   return true;
		   }
		}
	return false;
  }

public  LinkedList<String> keys(){
	return  Query.keySet();
}
public void UpdatePastQueries(Webpage newpage){
	for (String key : Query.keySet() ) {
		   if(newpage.InWebpage(key)){
			   Query.put(key, Query.get(key));
			   //add the webpage to corresponding query
		   }
		}
}


}
