# About Worcester

Worcester is the third largest city in Massachusetts. It is home to many universities, including [WPI](aboutWPI.md).
