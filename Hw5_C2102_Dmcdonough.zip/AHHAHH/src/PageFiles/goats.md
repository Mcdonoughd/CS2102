# Caring for Your Goat

This page talks about how to feed your pet goat.
Goats will eat anything you leave lying around.
