import java.util.LinkedList;

class Webpage {
 public String url;
 private String title;  
 private String body;   
 private LinkedList<String> referencedURLs;

  // The constructor converts title and body to lowercase, to ease
  //  other computations later
  Webpage(String locator, String title, String body,
          LinkedList<String> referencedURLs) {
    this.url = locator;
    this.title = title.toLowerCase();
    this.body = body.toLowerCase();
    this.referencedURLs = referencedURLs;
  }
  //returns a webpage's url
  public String WebUrl(){
	  return this.url.toLowerCase();
  }
  
  //produces if true if string is contained in URL, Title, or Body
  public boolean InWebpage(String astring){
	  if(this.url.contains(astring.toLowerCase())||this.body.contains(astring.toLowerCase())||this.title.contains(astring.toLowerCase())){
		  return true;
	  }
	  else{
		  return false;
	  }
  }
  
  public boolean equals(Webpage apage){
	  if(this.url== apage.url && this.body== apage.body &&this.title== apage.title){
		 return  true;
	  }
	  else{
		  return false;
	  }
  }
  
  
  
}