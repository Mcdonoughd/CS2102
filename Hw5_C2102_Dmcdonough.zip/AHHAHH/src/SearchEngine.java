/* Starter file for homework 5 
 * 
 * The file is marked throughout with what you can, cannot, and should not need to edit.
 */

import java.util.LinkedList;
import java.util.Arrays;
import java.util.Scanner;
import java.io.*;
import java.util.HashMap;
class SearchEngine implements ISearchEngine {
  // leave these first two variables alone
  Scanner keyboard = new Scanner(System.in);
  SimpleMarkdownReader m = new SimpleMarkdownReader();
  
  // you are welcome to replace the pages variable with your own data structures.
  // the specific name "pages" will not be referenced in any of our tests/autograding
  private LinkedList<Webpage> visitedpages = new LinkedList<Webpage>();
  private QueryHashMap Queryset;
  
  
  // constructor
  // you are welcome to change what the constructor does, as long as you leave the header intact
  SearchEngine(LinkedList<String> initPages) throws FileNotFoundException, UnsupportedFileExn {
	  
	  //converts the engines' list of URLs into a list of webpages
	  for (String pageLoc : initPages) {
	      visitedpages.add(addSite(pageLoc));
	    }
 };
 
//makes a query lowercase and removes filler words
	private String shortQuery(String Query){
		return stripFillers(Query.toLowerCase());
	}

	
	 public LinkedList<Webpage> InVisitedSites(String query){
		  LinkedList<Webpage>MatchQuery = new LinkedList<Webpage>();
		for(Webpage apage: visitedpages){
			if(apage.InWebpage(query)){
				MatchQuery.add(apage);
			}
		}	  
		  return MatchQuery; 
	  }

	
	
  // ****** THE SEARCH ENGINE METHODS YOU NEED TO PROVIDE ***********
  // Even if you encapuslate (full version), leave methods with these headers
  //   in the SearchEngine class (our tests/autograding expect to find them here)
 
  // given query string, produce webpages that meet query
  // you will need to edit this, but do not edit the header (autograding expects this)
  public LinkedList<Webpage> runQuery(String query) {
	  if(alreadySawQuery(stripFillers(query.toLowerCase()))){
		  return Queryset.getquery(shortQuery(query));
	  }
	  else{
		  System.out.println("AAAAAAA");
		  return addQuery(shortQuery(query), InVisitedSites(shortQuery(query)));
	  }
  }
  
  
  public  LinkedList<Webpage> addQuery(String query, LinkedList<Webpage> Match){
		Queryset.addQuery(query, Match);
		return Match;
	}

  
  
  
  
  
  
  // given a page location, return the corresponding page after updating queries
  // you will need to edit this, but do not edit the header (autograding expects this)
  public Webpage visitPage(String location) throws UnsupportedFileExn, FileNotFoundException {
	  System.out.println("WOW");
	  if (visitedpages.contains(addSite(location))){
		  System.out.println("it was in the list WOW");
		  return addSite(location);
	  }
	  else{
		  System.out.println("it was in the list WOW");
		  visitedpages.add(addSite(location));
		  for (String key : Queryset.keys() ) {
			   if(addSite(location).InWebpage(key)){
				   Queryset.addQuery(key, Queryset.getquery(key));
				   Queryset.getquery(key).add(addSite(location));
					
				   //add the webpage to corresponding query
			   }
			};
		  return addSite(location);
	  }
	  
	  
	  
  }
  
  // produce the number of web pages known in the system
  // you are welcome to edit this method as long as you leave the header intact (autograding expects this)
  public int knownPageCount() {
    return visitedpages.size();
  }
  
  // determine whether given query has been seen in the search engine
  // you will need to edit this, but do not edit the header (autograding expects this)
  public boolean alreadySawQuery(String query) {
	  for (String key : Queryset.keys() ) {
		   if(key.equals(query)){
			   return true;
		   }
		}
	return false;
  }
  
  // ***** THE SCREEN/USER INTERFACE *******************
  // You should NOT need to edit this method
  void screen() {
    System.out.println("-------------------------------------");
    System.out.println("Enter a number to select an option");
    System.out.println("1. Search for pages");
    System.out.println("2. Visit a page");
    System.out.println("3. Exit the system (and lose all index data)");
    String choice = keyboard.next();
    // eat up the rest of the line
    keyboard.nextLine();
    
    try {
      if (choice.equals("1")) {
        System.out.println("Enter your query:");
        String query = keyboard.nextLine();
        System.out.println("Search results: ");
        System.out.println(runQuery(query));
        screen();
      }
      else if (choice.equals("2")) {
        System.out.println("Which page (filename) do you want to visit?:");
        String filename = keyboard.next();
        System.out.println(visitPage(filename));
        screen();
      }
      else if (choice.equals("3"))
        System.out.println("Thanks for searching with us");
      else 
        System.out.println("ERROR *** Unrecognized option " + choice + ". Try again");
    } catch (UnsupportedFileExn e) {
      System.out.println("ERROR *** Filetype not supported: " + e.filename);
      screen();
    } catch (FileNotFoundException e) {
      System.out.println("ERROR *** No page found at address " + e);
      screen();
    }
  }

  // ****** ADDING SITES TO THE ENGINE ***************
  // parses given file into a webpage
  // you are welcome to edit this method as long as you leave the header intact.
  // you should NOT need to edit the call to readPage (you may want to add statements around it though)
 private Webpage addSite(String locationName) throws UnsupportedFileExn, FileNotFoundException {
    if (locationName.endsWith(".md")) {
      return(m.readPage(locationName));
    } else {
      throw new UnsupportedFileExn(locationName);
    }
  }
  
  // ****** REMOVING FILLER WORDS FROM QUERIES *****************
  // Don't edit either the list of fillerWords or the stripFillers method
  private LinkedList<String> fillerWords = 
    new LinkedList<String>(Arrays.asList("a", "an", "the", "of", "on", "in", 
                                         "to", "by", "about", "how", "is",
                                         "what", "when"
                                        ));
  
  // remove the filler words from a string
  // assume string has no punctuation
  private String stripFillers(String query) {
    String[] wordArray = query.toLowerCase().split(" ");
    String resultStr = "";
    for (int i = 0 ; i < wordArray.length ; i++) {
      if (!(fillerWords.contains(wordArray[i])))
        resultStr = resultStr + wordArray[i];
    }
    return resultStr;
  }
 
}
