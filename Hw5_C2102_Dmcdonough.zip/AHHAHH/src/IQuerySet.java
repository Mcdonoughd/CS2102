import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.util.LinkedList;

import org.junit.Test;


	 interface IQuerySet {
		  boolean alreadySawQuery(String query);
		  LinkedList<Webpage> getquery(String query);
		  LinkedList<Webpage> addQuery(String query, LinkedList<Webpage> Match);
		  void UpdatePastQueries(Webpage newpage);
	}


