import static org.junit.Assert.*;

import org.junit.Test;

public class BiathlonResult implements IEvent{
	BiathlonRound round1;
	BiathlonRound round2;
	BiathlonRound round3;
	BiathlonResult abiatholonresult;


BiathlonResult(BiathlonRound round1, BiathlonRound round2, BiathlonRound round3){
this.round1=round1;
this.round2=round2;
this.round3=round3;
}

public double pointsEarned() {
return	( (round1.Roundscore()) + (round2.Roundscore()) + (round3.Roundscore()));
}

BiathlonRound bestRound(){
	if(((round1.Roundscore()) <= (round2.Roundscore())) && ((round1.Roundscore()) <= (round3.Roundscore())) ){
		return round1;
	}
	if(((round2.Roundscore()) <= (round1.Roundscore())) && ((round2.Roundscore()) <= (round3.Roundscore())) ){
		return round2;
	}
	else{
		return round3;
	}

}

};