import static org.junit.Assert.*;

import org.junit.Test;

public class CyclingResult implements IEvent{
	double time;
	int position;
	CyclingResult v;
	CyclingResult(double time,int position){
			this.time = time ;
			this.position = position;
	}
	public double pointsEarned() {
		if(this.position == 1){
			return (this.time - 10);
		}
		if(this.position == 2){
			return (this.time - 7);
		}
		if(this.position == 3){
			return (this.time - 3);
		}
		return this.time;
	}
	public boolean betterscore(CyclingResult v){
		if(this.pointsEarned() <= v.pointsEarned()){
			return true;
		}
		else{
			return false;
		}
	}
	}
