import static org.junit.Assert.*;

import org.junit.Test;


public interface IEvent{
		public double pointsEarned();
	}

