import static org.junit.Assert.*;

import org.junit.Test;

public class Athlete{
	CyclingResult v;
	BiathlonResult b;
	Athlete anAthlete;
	
	Athlete (BiathlonResult b, CyclingResult v ){
		this.v = v;
		this.b = b;
}
	
public double	totalScore(){
	return (v.pointsEarned() + b.pointsEarned());	
}
public boolean hasBeaten(Athlete anAthlete){
	if(this.totalScore() < anAthlete.totalScore()){
		return true;
	}
		else{
			return false;
		}
}
public Athlete betterCyclist1(Athlete anAthlete){
	if (this.v.betterscore(anAthlete.v)){
		return this;
	}
	else{
		return anAthlete;
	}
	
}

public Athlete betterCyclist2(Athlete anAthlete){
	if(this.v.pointsEarned() > anAthlete.v.pointsEarned()){
			return anAthlete;}
	else{
		return this;
	}
}

}