import static org.junit.Assert.*;

import org.junit.Test;


public class BiathlonRound{
	double time;
	int targetHits;
	double helper;
	BiathlonRound around;
	
	 BiathlonRound(int targetHits, double time){
		this.time = time; 
		this.targetHits= targetHits;		
		}
	double Roundscore(){
		return (this.time - (60 * (this.targetHits - 5)));
	}
}