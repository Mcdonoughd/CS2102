import static org.junit.Assert.*;

import org.junit.Test;

public class Examples {
//Daniel McDonough
//Jennifer Payano

BiathlonRound Joeround1 = new BiathlonRound(5,60);
BiathlonRound Joeround2 = new BiathlonRound(4,30);
BiathlonRound Joeround3 = new BiathlonRound(1,80);
BiathlonResult JoeBResult = new BiathlonResult(Joeround1,Joeround2,Joeround3);
CyclingResult JoeCResult = new CyclingResult(120,4);
Athlete Joe = new Athlete(JoeBResult,JoeCResult);

BiathlonRound Anaround1 = new BiathlonRound(5,80);
BiathlonRound Anaround2 = new BiathlonRound(1,10);
BiathlonRound Anaround3 = new BiathlonRound(4,20);
BiathlonResult AnaBResult = new BiathlonResult(Anaround1,Anaround2,Anaround3);
CyclingResult AnaCResult = new CyclingResult(90,1);
Athlete Ana = new Athlete(AnaBResult,AnaCResult);


@Test
public void pointsEarned(){
	assertEquals( JoeBResult.pointsEarned(), 470,0);
	assertEquals( AnaBResult.pointsEarned(), 410,0);
	assertEquals( JoeCResult.pointsEarned(), 120,0);
	assertEquals( AnaCResult.pointsEarned(), 80,0);
}

@Test
public void bestRound(){
	assertEquals(JoeBResult.bestRound(), Joeround1);
	assertEquals(AnaBResult.bestRound(), Anaround1);
}	
@Test
public void totalScore(){
	assertEquals(Joe.totalScore(), 590,0);
	assertEquals(Ana.totalScore(), 490,0);
}		
@Test
public void hasBeaten(){
	assertFalse(Joe.hasBeaten(Ana));
	assertTrue(Ana.hasBeaten(Joe));
}	
@Test
public void betterCyclist1(){
	assertEquals(Joe.betterCyclist1(Ana),Ana);
}
@Test
public void betterCyclist2(){
	assertEquals(Joe.betterCyclist2(Ana),Ana);
}
@Test
public void Roundscore(){
	assertEquals(Joeround1.Roundscore(),60,0 );
}
@Test
public void betterscore(){
	assertTrue(AnaCResult.betterscore(JoeCResult) );
	assertFalse(JoeCResult.betterscore(AnaCResult) );
}
}
