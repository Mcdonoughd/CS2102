import static org.junit.Assert.*;

import java.util.LinkedList;

import org.junit.Test;

public class FailedLoginPattern implements IPattern {

	public LinkedList<AbsEvent> helper(EventLog log, String uname) {
		LinkedList<AbsEvent> errors = new LinkedList<AbsEvent>();

		for (AbsEvent event : log.getLog()) {
			if (event.isByUser(uname) && (event.getType() == AbsEvent.LOGIN) && (!((Login) event).wasSuccessful())) {
				errors.add(event);
			}

		}
		// returns only a list of errors
		return errors;
	}

	@Override
	public LinkedList<Alert> run(EventLog log, LinkedList<String> usernames) {
		LinkedList<Alert> raiseAlerts = new LinkedList<Alert>();

		for (String uname : usernames) {
			LinkedList<AbsEvent> errors = helper(log, uname);
			long maintime;
			int severity = (Integer) Math.max(errors.size(), 10);
			
			
			for (int i = 0; i < errors.size()-3; i++) {
					maintime = errors.get(i).getTimestamp().getTime();
					long secondtime = errors.get(i+3).getTimestamp().getTime();
					long diff = secondtime - maintime;
				      if (diff / 60000.0 <= 5.0) { 
				    
							raiseAlerts.add(new Alert(uname, severity, AbsEvent.LOGIN));
							break;
				    	  }

			}
			
		}

		return raiseAlerts;
	}
}
