import java.util.LinkedList;
import java.util.Arrays;
import static org.junit.Assert.*;
import org.junit.Test;

public class Examples {
  // customize here, or create multiple monitors with different parameter lists
  SecurityMonitor SM = 
    new SecurityMonitor(new LinkedList<IPattern>(Arrays.asList(new FailedLoginPattern(),new LargeFilePattern(),new SuspiciousWebPattern())));
  //checks savelog
  SecurityMonitor SM2 = 
		    new SecurityMonitor(new LinkedList<IPattern>(Arrays.asList(new LargeFilePattern())));
  //checks savelog2
  SecurityMonitor SM22 = 
		    new SecurityMonitor(new LinkedList<IPattern>(Arrays.asList(new LargeFilePattern())));
  //checks loginlog
  SecurityMonitor SM3 = 
		    new SecurityMonitor(new LinkedList<IPattern>(Arrays.asList(new FailedLoginPattern())));
  //checks loginlog2
  SecurityMonitor SM32 = 
		    new SecurityMonitor(new LinkedList<IPattern>(Arrays.asList(new FailedLoginPattern())));
  //checks largeLog1
  SecurityMonitor SM4 = 
		    new SecurityMonitor(new LinkedList<IPattern>(Arrays.asList(new FailedLoginPattern(),new LargeFilePattern())));
  //checks eventLog1
  SecurityMonitor SM5 = 
		    new SecurityMonitor(new LinkedList<IPattern>(Arrays.asList(new FailedLoginPattern(),new SuspiciousWebPattern())));
  //checks eventLog2
  SecurityMonitor SM52 = 
		    new SecurityMonitor(new LinkedList<IPattern>(Arrays.asList(new FailedLoginPattern(),new SuspiciousWebPattern())));
  //checks largestLog
  SecurityMonitor SM6 = 
		    new SecurityMonitor(new LinkedList<IPattern>(Arrays.asList(new FailedLoginPattern(),new SuspiciousWebPattern(),new LargeFilePattern())));
  Alert Alert1 =
		  new Alert("Steve", 10, 6);
  Alert Alert2 =
		  new Alert("Steve", 10, 6);	
  Alert Alert3 =
		  new Alert("Joe", 5, 6);	
  
  // use this fixed set of usernames -- it is what we have in all the logs
  LinkedList<String> usernames = new LinkedList<String>(Arrays.asList("root","kathi", "simmon", "jordan"));
  
  public Examples() {
    // reset the queue between test cases
    SM.clearQueue();
    // populate the queue based on a specific log
    SM.runLogFile("./src/webrequestlog.txt", usernames);
	  SM2.clearQueue();
	    // populate the queue based on a specific log
	    SM2.runLogFile("./src/saveLog.txt", usernames);
		  SM22.clearQueue();
		    // populate the queue based on a specific log
		    SM22.runLogFile("./src/saveLog2.txt", usernames);
		  SM3.clearQueue();
		    // populate the queue based on a specific log
		    SM3.runLogFile("./src/loginLog.txt", usernames);
		    SM32.clearQueue();
		    // populate the queue based on a specific log
		    SM32.runLogFile("./src/loginLog2.txt", usernames);
		    SM4.clearQueue();
		    // populate the queue based on a specific log
		    SM4.runLogFile("./src/largeLog1.txt", usernames);
		    SM5.clearQueue();
		    // populate the queue based on a specific log
		    SM5.runLogFile("./src/eventLog1.txt", usernames);
		    SM52.clearQueue();
		    // populate the queue based on a specific log
		    SM52.runLogFile("./src/eventLog2.txt", usernames);
		    SM6.clearQueue();
		    // populate the queue based on a specific log
		    SM6.runLogFile("./src/largestLog.txt", usernames);
  }
  
  // check whether the webrequest sample yields a single alert (as it should)
  @Test
  public void checkWebRequestAlerts() {
    assertEquals(1, SM.numAlerts());
    assertEquals(SM.topAlert(),SM.handleAlert() );
    
  }
  
  @Test
  public void checksaveLogAlerts() {
    assertEquals(1, SM2.numAlerts());
    assertEquals(SM2.topAlert(),SM2.handleAlert() );
    
  }
  
  @Test
  public void checkloginLogAlerts() {	
    assertEquals(1, SM3.numAlerts());
    assertEquals(SM3.topAlert(),SM3.handleAlert() );
    
  }
  @Test
  public void checkloginLog2Alerts() {
	  assertEquals(0, SM32.numAlerts());
	   assertEquals(SM32.topAlert(),SM32.handleAlert() );
	    
  }
  @Test
  public void checksaveLog2Alerts() {
	  assertEquals(2, SM22.numAlerts());
	   assertEquals(SM22.topAlert(),SM22.handleAlert() );
	    
  }
  @Test
  public void checklargeLog1Alerts() {
	  assertEquals(3, SM4.numAlerts());
	   assertEquals(SM4.topAlert(),SM4.handleAlert() );
	    
  }
  @Test
  public void checkeventLog1Alerts() {
	  assertEquals(4, SM5.numAlerts());
	   assertEquals(SM5.topAlert(),SM5.handleAlert() );
	    
  }
  @Test
  public void checkeventLog2Alerts() {
	  assertEquals(4, SM52.numAlerts());
	   assertEquals(SM52.topAlert(),SM52.handleAlert() );
	    
  }
  @Test
  public void checklargestLogAlerts() {
	  assertEquals(3, SM6.numAlerts());
	   assertEquals(SM6.topAlert(),SM6.handleAlert() );
	    
  }
  @Test
  public void checkAlerts() {
	  assertTrue(Alert1.equals(Alert2));
	  assertFalse(Alert3.equals(Alert1));  
	  assertEquals(-1, Alert1.compareTo(Alert3));
	  assertEquals(1, Alert3.compareTo(Alert2));
	  assertEquals(0, Alert1.compareTo(Alert2));
  }
  
}