import static org.junit.Assert.*;

import org.junit.Test;

public class Alert implements Comparable{
	String username;
	int severity;
	int eventType;
	public Alert(String username,int severity,	int eventType){
		this.username = username;
		this.severity=severity;
		this.eventType =eventType;
	}
	 public int compareTo(Object otherObj) {
	      Alert other = (Alert) otherObj;
	      if(this.severity > other.severity){
	    	  return -1;
	      }
	      else if (this.severity < other.severity){
	    	  return 1;
	      }
	      else{
	    	  return 0;
	      }
	      // insert the code to do the comparison here
		
	  }
	 public boolean equals(Alert other){
		if(this.username == other.username && this.severity == other.severity && this.eventType == other.eventType){
			return true;
		}
		else{
			return false;
		}
		 
	 }

}
