import static org.junit.Assert.*;

import java.util.LinkedList;

import org.junit.Test;

public class LargeFilePattern implements IPattern{


	@Override
	public LinkedList<Alert> run(EventLog log, LinkedList<String> usernames) {
		LinkedList<Alert> raiseAlerts = new LinkedList<Alert>();

		for(String uname: usernames){
			int counter = 0;
			for (AbsEvent event : log.getLog()) {
				if (event.isByUser(uname) && (event.getType() == AbsEvent.FILE_SAVED))  {
					if(((FileSaved)event).getSize() > 1000000){
						counter++;
					}
				}
			}
			if(counter>1){
				int severity = (Integer)Math.max((counter / 1), 10);
				Alert a = new Alert(uname, severity, AbsEvent.FILE_SAVED);
				raiseAlerts.add(a);
				//raiseAlerts.add(new Alert(uname,counter, AbsEvent.FILE_SAVED));
			}
		}

		return raiseAlerts;
	}

}
