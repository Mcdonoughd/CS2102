import java.io.FileNotFoundException;
import java.util.LinkedList;

public class Main {
	 public static void main(String[] args) throws FileNotFoundException, UnsupportedFileExn {
		 SearchEngine s = new SearchEngine(new LinkedList<String>());
		 s.screen();
	 }
}
