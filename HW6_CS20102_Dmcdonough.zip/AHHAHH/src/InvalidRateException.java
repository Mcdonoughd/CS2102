
public class InvalidRateException extends Exception {
	double rate;
	public InvalidRateException(double rate) {
		// TODO Auto-generated constructor stub
		this.rate = rate;
	}

}
