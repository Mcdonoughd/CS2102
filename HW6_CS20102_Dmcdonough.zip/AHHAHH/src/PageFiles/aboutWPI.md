# About WPI

Located in Worcester, MA, [WPI](http://www.wpi.edu) was founded in 1865 as one of the nation's first engineering and
technology universities. The founders were John Boynton and Ichabod Washburn. The school's motto
is Lehr und Kunst (or Theory and Practice), and its mascot is a goat.
