
public class LowerRateException extends Exception {
	double rate;
	 double oldrate;
	public LowerRateException(double rate,double oldrate) {
		// TODO Auto-generated constructor stub
		this.rate = rate;
		this.oldrate = oldrate;
	}

}
