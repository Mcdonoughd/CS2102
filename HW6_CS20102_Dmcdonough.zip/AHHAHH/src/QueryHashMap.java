import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;


import org.junit.Test;

 class QueryHashMap {
	private HashMap<String, LinkedList<Webpage>> Query= new HashMap<String, LinkedList<Webpage>>();
	 
	 QueryHashMap(){
		 HashMap<String, LinkedList<Webpage>> Query = new HashMap<String, LinkedList<Webpage>>();

	 }
	// gets a list of past queries and checks if null
	 public LinkedList<Webpage> getquery2(String query){
			if(Query.isEmpty()){
				return null;
			}
			else if(Query.containsKey(query)){
				Query.get(query);
			}
			return addQuery2(query, Query.get(query));
		}	 
//gets a list of past queries
public LinkedList<Webpage> getquery(String query,LinkedList<Webpage> Match){
	if(Query.isEmpty()){
		 addQuery(query, Match);
	}
	else if(Query.containsKey(query)){
		Query.get(query);
	}
	return Match;
}
//adds query to past querys and runs query (checks if past queries are null)
public LinkedList<Webpage> addQuery2(String query, LinkedList<Webpage> Match){
	if(Query.containsKey(query)){
		 Query.put(query, Query.get(query));
	}
	else{
	Query.put(query, Match);
	return Match;
	}
	return Match;
}

//adds query to past querys and runs query
public  LinkedList<Webpage> addQuery(String query, LinkedList<Webpage> Match){	
	Query.put(query, Match);
	return getquery2(query);
}


//returns list of keys
public  LinkedList<String> keys(){
	LinkedList<String>keys = new LinkedList<String>();
	
	List<String> result = new ArrayList<String>(Query.keySet());
	//List<String> result = Query.entrySet().stream().map(x -> x.getKey()).collect(Collectors.toList());
	keys.addAll(result);
	return keys;
}

//checks if query has been looked before
public boolean containsKey(String query2) {
	if(Query.isEmpty()){
	return false;
	}
	return Query.containsKey(query2);
}

//gets size of query
public int sizelen(){
	return Query.size();
}



}
