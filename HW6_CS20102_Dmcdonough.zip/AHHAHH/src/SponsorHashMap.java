import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Set;

import org.junit.Test;

public class SponsorHashMap {

	private  HashMap<String, Double> Sponsor= new HashMap<String, Double>();
	 
	SponsorHashMap(){
		 HashMap<String, Double> Sponsor = new HashMap<String, Double>();
	 }
	//getter for a sponsors' value for given key
	public Double Get(String name){
		return Sponsor.get(name);
	}
	//putter for a sponsor' value and corresponding key
	public void  Put(String name, Double amount){
		 Sponsor.put(name, amount);
	}
//checks if key is in hashmap
	public boolean containsKey(String sponsor2) {
		if(Sponsor.containsKey(sponsor2)){
			return true;
		}
		else{
		return false;
		}
	}
	//returns list of keys
	public Set<String> keys(){
		return Sponsor.keySet();
	}

}
