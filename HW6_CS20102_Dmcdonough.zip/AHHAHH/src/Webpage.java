import java.util.LinkedList;

class Webpage implements Comparable<Webpage>{
 public String url;
 private String title;  
 private String body;   
 private LinkedList<String> referencedURLs;
 public double rank;
  // The constructor converts title and body to lowercase, to ease
  //  other computations later
  Webpage(String locator, String title, String body,
          LinkedList<String> referencedURLs) {
    this.url = locator;
    this.title = title.toLowerCase();
    this.body = body.toLowerCase();
    this.referencedURLs = referencedURLs;
    this.rank = 0;
  }
  //returns a webpage's url
  public String WebUrl(){
	  return this.url;
  }
  
  //changes a webrank based on given double
  public Double WebRank(double points){
	  return this.rank = points;
  }
  //resets webrank to 0
  public void resetrank(){
	  this.rank=0;
  }
  
 //getter for list of reference links
  public LinkedList<String> refURLs(){
	  return this.referencedURLs;
  }
  
  
  //produces if true if string is contained in URL, Title, or Body
  public boolean InWebpage(String astring){
	  if(this.url.toLowerCase().contains(astring)||this.body.toLowerCase().contains(astring)||this.title.toLowerCase().contains(astring)){
		  return true;
	  }
	  else{
		  return false;
	  }
  }
  
  //checks if two pages are equal
  public boolean equals(Webpage apage){
	  if(this.url== apage.url && this.body== apage.body &&this.title== apage.title){
		 return  true;
	  }
	  else{
		  return false;
	  }
  }
  
  //compares two webpages
@Override
public int compareTo(Webpage apage) {
	if(this.rank == apage.rank){
		return 0;
	}
	else if(this.rank > apage.rank){
		return 1;
	}
	else{
		return -1;
	}
	
}
  
  
  
}