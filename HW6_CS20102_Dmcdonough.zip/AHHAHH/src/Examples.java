/*
 * If you are looking at this file before Thurs/Fri, the try/catch
 * statements won't make sense (unless you already know exceptions).
 * By Friday, we will cover those.  In the meantime, you can write
 * tests by creating your search engine classes in the Examples
 * constructor, as indicated by the comments.
 */

import java.util.LinkedList;
import java.util.Arrays;
import static org.junit.Assert.*;
import org.junit.Test;
import java.io.*;

public class Examples {
  // declare variables for all of your search engines here
  SearchEngine s; 
  
  // local method to add a page to a search engine.  Created a
  //   helper so that we can isolate the exception handling here,
  //   rather than clutter up each test case with the exceptions
  private void addPage(SearchEngine s, String p) {
    try {
      s.visitPage(p);
    } catch (FileNotFoundException e) {
      fail("Aborting Example setup -- file not found: " + e);
    } catch (UnsupportedFileExn e) {
      fail("Aborting Examples setup -- unsupported file extension: " + e);
    }
  }
  
  public Examples(){
    try {
      // set up all of your search engines with pages here
      // rather than in the individual tests (or you will have
      // to copy the exceptions code into the test classes)
      s = new SearchEngine(new LinkedList<String>());
      
      addPage(s, "./src/PageFiles/goats.md");
      addPage(s, "./src/PageFiles/aboutWPI.md");
      try {
		s.updateSponsor("WPI",0.1);
	} catch (LowerRateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (InvalidRateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    } catch (FileNotFoundException e) {
      System.out.println("Aborting Example setup -- file not found: " + e);
    } catch (UnsupportedFileExn e) {
      System.out.println("Aborting Examples setup -- unsupported file extension: " + e);
    }
  }
  
  @Test
  public void testGoatsQuery() {
    assertEquals(s.runQuery("goat").size(), 2);
    assertEquals(s.knownPageCount(),2);
  }
  @Test
  public void alreadydidnot(){
	
  }
  @Test
  public void testWPIQuery() throws FileNotFoundException, UnsupportedFileExn {
    assertEquals(s.runQuery("WPI").size(), 1);
    addPage(s, "./src/PageFiles/worcester.md");

    //s.visitPage("./src/PageFiles/worcester.md");
    assertEquals(s.runQuery("WPI").size(), 2);
    assertEquals(s.knownPageCount(),3);
  }
  @Test
  public void alreadydid(){
	  assertFalse(s.alreadySawQuery("WPI"));
	  s.runQuery("WPI");
	  assertTrue(s.alreadySawQuery("WPI"));
	  //tests that come up empty an empty list
	  assertEquals(s.runQuery("Squirels and A").size(),0);
	  assertEquals(s.runQuery("WPI andA").size(),0);
  }
  
  
  @Test(expected = InvalidRateException.class)
  public void invalidRateTest1() throws LowerRateException,InvalidRateException {
    s.updateSponsor("WPI", 2.0);
    s.updateSponsor("Wpi", -100);
  }
  @Test(expected = LowerRateException.class)
  public void LowRateTest1() throws LowerRateException,InvalidRateException {
    s.updateSponsor("WPI", 0);
  }
  
  @Test
  public void expectedranks(){
	 assertTrue( s.getSponsoredRate("./src/PageFiles/aboutWPI.md").equals(0.1));
  }
  @Test
  public void expectedranksaftertwoRUNQUERIES(){
	 assertTrue( s.getSponsoredRate("./src/PageFiles/aboutWPI.md").equals(0.1));
	 s.runQuery("WPI");
	 s.runQuery("WPI");
	 assertTrue( s.getSponsoredRate("./src/PageFiles/aboutWPI.md").equals(0.1));
	 
  }
  @Test
  public void checkpositions() throws FileNotFoundException, UnsupportedFileExn{
	 //about WPI is the first webpage to be put in the results
	  assertEquals(s.runQuery("WPI").getFirst().WebUrl(),"./src/PageFiles/aboutWPI.md");
  }
}
