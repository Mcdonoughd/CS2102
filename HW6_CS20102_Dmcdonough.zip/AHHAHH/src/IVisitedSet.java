import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.util.LinkedList;

import org.junit.Test;
interface IVisitedSet   {
	
	int knownPageCount();
	LinkedList<Webpage> InVisitedSites(String stripFillers);
	void addPage(String Url) throws UnsupportedFileExn;
	boolean hasinList(String Url);
}
