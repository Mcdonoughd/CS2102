
import java.io.FileNotFoundException;
import java.util.LinkedList;


public class VisitedList {
private LinkedList<Webpage> VisitedPages = new LinkedList<Webpage>(); 

public boolean hasinList(String Url){
	if(VisitedPages.size()>0){
	for(Webpage visitedpage: VisitedPages){
		if(visitedpage.WebUrl().equals(Url)){
			return true;
		}
	}
	}
	return false;
}

  // produce the number of web pages known in the system
  // you are welcome to edit this method as long as you leave the header intact (autograding expects this)
  public int knownPageCount() {
    return VisitedPages.size();
  }

  //makes list of WebPages that contain a specific string
  public LinkedList<Webpage> InVisitedSites(String query){
	  LinkedList<Webpage>MatchQuery = new LinkedList<Webpage>();
	for(Webpage apage: VisitedPages){
		if(apage.InWebpage(query)){
			MatchQuery.add(apage);
		}
	}	  
	  return MatchQuery; 
  }

public void addPage(String Url) throws UnsupportedFileExn {
	if (Url.endsWith(".md")) {
	for(Webpage page: VisitedPages){
		if(page.WebUrl().equals(Url)){
			VisitedPages.add(page);
		}	
}
	System.out.println("Not in system");
	 } else {
	      throw new UnsupportedFileExn(Url);
	    }
}
}
