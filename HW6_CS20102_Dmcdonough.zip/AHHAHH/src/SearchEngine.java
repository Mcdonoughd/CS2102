/* Starter file for homework 5 
 * 
 * The file is marked throughout with what you can, cannot, and should not need to edit.
 */

import java.util.LinkedList;
import java.util.List;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Set;
import java.io.*;
import java.util.HashMap;
import java.util.Collections;

class SearchEngine implements ISearchEngine {
  // leave these first two variables alone
  Scanner keyboard = new Scanner(System.in);
  SimpleMarkdownReader m = new SimpleMarkdownReader();
  
  // you are welcome to replace the pages variable with your own data structures.
  // the specific name "pages" will not be referenced in any of our tests/autograding
 // private LinkedList<Webpage> visitedpages = new LinkedList<Webpage>();
  private LinkedList<Webpage> visitedpages = new LinkedList<Webpage>();
  private QueryHashMap Query = new QueryHashMap();
  private SponsorHashMap Sponsor = new SponsorHashMap();
  private LinkedList<String> pastQuery = new LinkedList<String>();
  
  
  // constructor
  // you are welcome to change what the constructor does, as long as you leave the header intact
  SearchEngine(LinkedList<String> initPages) throws FileNotFoundException, UnsupportedFileExn {
	  
	  //converts the engines' list of URLs into a list of webpages
	  for (String pageLoc : initPages) {
	      visitedpages.add(addSite(pageLoc));
	    }
 };
 
//makes a query lowercase and removes filler words
	private String shortQuery(String Query){
		return stripFillers(Query.toLowerCase());
	}

	
	//checks if a string is in a webpages' body title or URL and returns a list of pages that match
	 private LinkedList<Webpage> InVisitedSites(String query){
		  LinkedList<Webpage>MatchQuery = new LinkedList<Webpage>();
		for(Webpage apage: visitedpages){
			if(apage.InWebpage(shortQuery(query))){
				MatchQuery.add(apage);
			}
		}	 
		if(MatchQuery!=null){
			return MatchQuery;	
		}
		return MatchQuery;
	  }

	
	
  // ****** THE SEARCH ENGINE METHODS YOU NEED TO PROVIDE ***********
  // Even if you encapuslate (full version), leave methods with these headers
  //   in the SearchEngine class (our tests/autograding expect to find them here)
 
  // given query string, produce webpages that meet query
  // you will need to edit this, but do not edit the header (autograding expects this)
  public LinkedList<Webpage> runQuery(String query) {
	  if(alreadySawQuery(shortQuery(query))){
		  UpdateRank();
		  return Filterbyrank(Query.getquery(shortQuery(query),InVisitedSites(shortQuery(query))));
	  }
	  else{
		  pastQuery.add(shortQuery(query));	
		  UpdateRank();
		 return  Filterbyrank(Query.addQuery2(shortQuery(query),InVisitedSites(shortQuery(query))));		  
	  }
  }


  // given a page location, return the corresponding page after updating queries
  // you will need to edit this, but do not edit the header (autograding expects this)
  public Webpage visitPage(String location) throws UnsupportedFileExn, FileNotFoundException {
	  if (visitedpages.contains(addSite(location))){
		  System.out.println("you visited this page already");
		  return addSite(location);
	  }
	  else{
		  visitedpages.add(addSite(location));
		  System.out.println("add to history");
		  for (String key: pastQuery) {
			   if(addSite(location).InWebpage(key)){
				   Query.addQuery(key, Query.getquery2(key));
				   Query.getquery2(key).add(addSite(location));
				   
				   //add the webpage to corresponding query
			   }
			}
		  return addSite(location);
		  }
		
  }
  
 
  // produce the number of web pages known in the system
  // you are welcome to edit this method as long as you leave the header intact (autograding expects this)
  public int knownPageCount() {
    return visitedpages.size();
  }
  
  // determine whether given query has been seen in the search engine
  // you will need to edit this, but do not edit the header (autograding expects this)
  public boolean alreadySawQuery(String query) {
			if(pastQuery.contains(shortQuery(query))){
				return true;
			}
		return false;
	}
  
  // ***** THE SCREEN/USER INTERFACE *******************
  // You should NOT need to edit this method
  void screen() {
    System.out.println("-------------------------------------");
    System.out.println("Enter a number to select an option");
    System.out.println("1. Search for pages");
    System.out.println("2. Visit a page");
    System.out.println("3. Exit the system (and lose all index data)");
    String choice = keyboard.next();
    // eat up the rest of the line
    keyboard.nextLine();
    
    try {
      if (choice.equals("1")) {
        System.out.println("Enter your query:");
        String query = keyboard.nextLine();
        System.out.println("Search results: ");
        System.out.println(runQuery(query));
        screen();
      }
      else if (choice.equals("2")) {
        System.out.println("Which page (filename) do you want to visit?:");
        String filename = keyboard.next();
        System.out.println(visitPage(filename));
        screen();
      }
      else if (choice.equals("3"))
        System.out.println("Thanks for searching with us");
      else 
        System.out.println("ERROR *** Unrecognized option " + choice + ". Try again");
    } catch (UnsupportedFileExn e) {
      System.out.println("ERROR *** Filetype not supported: " + e.filename);
      screen();
    } catch (FileNotFoundException e) {
      System.out.println("ERROR *** No page found at address " + e);
      screen();
    }
  }

  // ****** ADDING SITES TO THE ENGINE ***************
  // parses given file into a webpage
  // you are welcome to edit this method as long as you leave the header intact.
  // you should NOT need to edit the call to readPage (you may want to add statements around it though)
 private Webpage addSite(String locationName) throws UnsupportedFileExn, FileNotFoundException {
    if (locationName.endsWith(".md")) {
      return(m.readPage(locationName));
    } else {
      throw new UnsupportedFileExn(locationName);
    }
  }
  
  // ****** REMOVING FILLER WORDS FROM QUERIES *****************
  // Don't edit either the list of fillerWords or the stripFillers method
  private LinkedList<String> fillerWords = 
    new LinkedList<String>(Arrays.asList("a", "an", "the", "of", "on", "in", 
                                         "to", "by", "about", "how", "is",
                                         "what", "when"
                                        ));
  
  // remove the filler words from a string
  // assume string has no punctuation
  private String stripFillers(String query) {
    String[] wordArray = query.toLowerCase().split(" ");
    String resultStr = "";
    for (int i = 0 ; i < wordArray.length ; i++) {
      if (!(fillerWords.contains(wordArray[i])))
        resultStr = resultStr + wordArray[i];
    }
    return resultStr;
  }
  
//updates a sponsor's pay rate but can only be higher than previous rate and between 0 and 0.1 or else error is thrown 
@Override
public void updateSponsor(String sponsor, double rate) throws LowerRateException, InvalidRateException {
	// TODO Auto-generated method stub
	if(rate>0.1 || rate<0){
		throw new InvalidRateException(rate);
	}
	else if (Sponsor.containsKey(sponsor)){
		if(Sponsor.Get(sponsor)>rate){
			throw new LowerRateException(rate,Sponsor.Get(sponsor));
		}
		else {
			Sponsor.Put(sponsor, rate);	
		}
	}
	else {
		Sponsor.Put(sponsor, rate);	
	}

}

//gets sponsored rate of a URL
public Double getSponsoredRate(String URL){
	for(String sponsors: Sponsor.keys()){
		//I am unsure weather a sponsor only sponsors a webpage with their name in the URl
		//or if the Url is just the sponsor's name
		//example does "WPI" sponsor /aboutWPI ?
		//in class prof. Kathi says no but it makes more sense if WPI does sponsor aboutWPI
		//if(URL.toLowerCase().contains("/"+sponsors.toLowerCase())){
	if(URL.toLowerCase().contains(sponsors.toLowerCase())){
	return Sponsor.Get(sponsors);
	}
	}
	return (double) 0;
}
//updates ranks for all pages in sponsored rates
public void UpdateRank(){
	resetRanks();
	WebLinkedRank();
	for(Webpage pages: visitedpages){
		pages.WebRank(getSponsoredRate(pages.WebUrl()));
	}
}
//resets ranks for all pages
private void resetRanks(){
	for(Webpage pages: visitedpages){
		pages.resetrank();
	}
}
//adds rank by linking to each page 
private void WebLinkedRank(){
	for(Webpage pages: visitedpages){
		if(!pages.refURLs().isEmpty()){
			for(String linkedpage: removecopys(pages.refURLs())){
				if(!(linkedpage.equals(pages.WebUrl()))){
					for(Webpage apage: visitedpages){
						if(apage.WebUrl().equals(linkedpage)){
							apage.WebRank(1/removeOG(removecopys(pages.refURLs()),pages).size());
						}
					}
				}
			}
		}
	}
}

//removes any copies of urls in the reference list
private LinkedList<String> removecopys(LinkedList<String> Urls){
	LinkedList<String>NoCopies = new LinkedList<String>();
	for(String url: Urls){
		if(!(NoCopies.contains(url))){
			NoCopies.add(url);
		}
	}
	return NoCopies;
}
//remove the urls in which the givin URL is is the same as any URL in the reference list
private LinkedList<String> removeOG(LinkedList<String> refURL, Webpage url){
	LinkedList<String>NoCopies = new LinkedList<String>();
	for(String urls: refURL){
		if(!(urls.equals(url.WebUrl()))){
			NoCopies.add(urls);
		}
		
	}
	return NoCopies;
}
//filters a list of webpage by ranks
public LinkedList<Webpage> Filterbyrank(LinkedList<Webpage> Searchresults){
	Collections.sort(Searchresults);
	return Searchresults;
}

 
}
