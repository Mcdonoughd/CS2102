import static org.junit.Assert.*;
import org.junit.Test;
import java.util.LinkedList;

public class Competition {
	int MaxBiathlonRounds;	
	int BiathlonRounds;
	Athlete anAthlete;
	LinkedList <Athlete> Athletes;
	Competition (LinkedList <Athlete> Athletes, int MaxBiathlonRounds ){
		this.Athletes=Athletes;
		this.MaxBiathlonRounds= MaxBiathlonRounds;

	}

	//takes a list of Athletes and produces a new list of Athletes that have less than the maximum biathlon rounds finished
	LinkedList <Athlete> BiathlonDNF(){
		LinkedList <Athlete> AthleteDNF = new LinkedList <Athlete>();
		for (Athlete a: this.Athletes){
			if(a.b.totalrounds() < this.MaxBiathlonRounds){
				AthleteDNF.add(a);
			}
		}
		return AthleteDNF;
	}
//returns totalscore for the Athlete in the competition with the given name
	double scoreForAthlete(String name){
		double dummy = 0;
		for (Athlete a: this.Athletes){
			if(a.name.equals(name)){
				return  a.totalScore();
			}
		}
		return  dummy;
	}




//compares the athlete's scores between two competitions and produces the number of athletes who have a lower score in the second competition
	int countCyclingImproved(Competition acomp){
		int runningcount = 0;
		for (Athlete a: this.Athletes){
			for (Athlete b: acomp.Athletes){
				if(b.name.equals(a.name)){
					if( a.v.betterscore(b.v)){
						runningcount++;
					} 
				}	

			}	 
		} 
		return runningcount;

	}
/*
 * In scoreForAthlete the dummy variable is useless and can be removed, 
 * In countCyclingImproved the second for loop could be replaced by scoreForAthlete and then be compared 
 * */

}
