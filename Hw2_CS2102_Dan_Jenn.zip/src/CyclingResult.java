import static org.junit.Assert.*;

import org.junit.Test;

public class CyclingResult extends AbsCycMar implements IEvent{
	
	
	CyclingResult v;
	CyclingResult(double time, int position){
			super(time,position);
	}
	//produces the points earned for a cycling round
	public double pointsEarned() {
		if(this.position == 1){
			return (this.time - 10);
		}
		else if(this.position == 2){
			return (this.time - 7);
		}
		else if(this.position == 3){
			return (this.time - 3);
		}
		return this.time;
	}
	//compares two cycling scores
	public boolean betterscore(CyclingResult v){
		if(this.pointsEarned() < v.pointsEarned()){
			return true;
		}
		else{
			return false;
		}
	}
	
	
	}
