import static org.junit.Assert.*;

import org.junit.Test;


public class BiathlonRound{
	double time;
	int targetHits;
	
	BiathlonRound around;
	
	 BiathlonRound(int targetHits, double time){
		this.time = time; 
		this.targetHits= targetHits;		
		}
	 //produces the score for one biathlon round
	double Roundscore(){
		return (this.time - (60 * (this.targetHits - 5)));
	}
}