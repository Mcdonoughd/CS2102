import static org.junit.Assert.*;

import org.junit.Test;

//holds common methods for cycling and biathlon and marathon events
public interface IEvent{
		public double pointsEarned();
	}

