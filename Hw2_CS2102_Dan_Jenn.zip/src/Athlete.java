import static org.junit.Assert.*;

import org.junit.Test;

public class Athlete{
	CyclingResult v;
	BiathlonResult b;
	Athlete anAthlete;
	String name;
	
	Athlete (String name, BiathlonResult b, CyclingResult v){
		this.v = v;
		this.b = b;
		this.name = name;
}

//calculates total score of biathlon and cycling scores	
public double	totalScore(){
	return (v.pointsEarned() + b.pointsEarned());	
}

//compares two Athletes produces true if the first athlete has a lower score than the second
public boolean hasBeaten(Athlete anAthlete){
	if(this.totalScore() < anAthlete.totalScore()){
		return true;
	}
		else{
			return false;
		}
}
//compares two Athletes, produces true if the first Athlete's cycling score is lower than the second
public Athlete betterCyclist1(Athlete anAthlete){
	if (this.v.betterscore(anAthlete.v)){
		return this;
	}
	else{
		return anAthlete;
	}
	
}
//compares two Athletes, produces true if the first Athlete's cycling score is lower than the second
public Athlete betterCyclist2(Athlete anAthlete){
	if(this.v.pointsEarned() > anAthlete.v.pointsEarned()){
			return anAthlete;}
	else{
		return this;
	}
}







}