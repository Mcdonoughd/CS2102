import static org.junit.Assert.*;

import org.junit.Test;
//abstract class combines common fields between Cycling and Marathon classes
abstract class AbsCycMar {

	double time;
	int position;
	
	AbsCycMar(double time, int position){
		this.time = time;
		this.position = position;
	}
	
}
