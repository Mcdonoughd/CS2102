import static org.junit.Assert.*;
import java.util.LinkedList;

import org.junit.Test;

public class BiathlonResult implements IEvent{
	BiathlonResult abiatholonresult;
	LinkedList <BiathlonRound> ListOfBiathlonRound;

BiathlonResult(LinkedList <BiathlonRound> ListOfBiathlonRound){
this.ListOfBiathlonRound=ListOfBiathlonRound;
}
//calculates the total points of all the rounds
public double pointsEarned() {
	int pointsCount=0;
	for(BiathlonRound r: ListOfBiathlonRound){
		pointsCount += r.Roundscore();
	}
return	pointsCount;
}
//produces the round with the lowest scoring round 
BiathlonRound bestRound(){
	BiathlonRound pointsCount= new BiathlonRound(0,999999999);
	for(BiathlonRound r: ListOfBiathlonRound){
		if(pointsCount.Roundscore() > r.Roundscore()){
			pointsCount = r;
		}
	}
	return pointsCount;
}
//produces the number of rounds in the biathlon
int totalrounds(){
	return this.ListOfBiathlonRound.size();
}

};