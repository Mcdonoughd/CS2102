import static org.junit.Assert.*;

import org.junit.Test;

public class MarathonResult extends AbsCycMar implements IEvent {
	
	
	MarathonResult(double time,int position){
		super(time,position) ;
		
}

	//produces the marathon's time
	public double pointsEarned() {
		return this.time;
	}

}
