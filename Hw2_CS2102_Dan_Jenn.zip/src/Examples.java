import static org.junit.Assert.*;

import java.util.LinkedList;

import org.junit.Test;

public class Examples {
//Daniel McDonough
//Jennifer Payano
	

public Examples(){
	ListOfJoeRound.add(Joeround1);
	ListOfJoeRound.add(Joeround2);
	ListOfJoeRound.add(Joeround3);
	ListOfAnaRound.add(Anaround1);
	ListOfAnaRound.add(Anaround2);
	ListOfAnaRound.add(Anaround3);
	ListOfAthletes.add(Joe);
	ListOfAthletes.add(Ana);
	ListOfAthletes.add(Mark);
	ListOfAthletesR.add(Ana);
	ListOfAthletesR.add(Mark);
	ListOfAthletesR.add(Joe);
	ListOfDNF.add(Mark);
	
}
BiathlonRound Joeround1 = new BiathlonRound(5,60);
BiathlonRound Joeround2 = new BiathlonRound(4,30);
BiathlonRound Joeround3 = new BiathlonRound(1,80);
LinkedList <BiathlonRound> ListOfJoeRound= new LinkedList <BiathlonRound>();
BiathlonResult JoeBResult = new BiathlonResult(ListOfJoeRound);
CyclingResult JoeCResult = new CyclingResult(120,4);
Athlete Joe = new Athlete("Joe",JoeBResult,JoeCResult);

BiathlonRound Anaround1 = new BiathlonRound(5,80);
BiathlonRound Anaround2 = new BiathlonRound(1,10);
BiathlonRound Anaround3 = new BiathlonRound(4,20);
LinkedList <BiathlonRound> ListOfAnaRound= new LinkedList <BiathlonRound>();

BiathlonResult AnaBResult = new BiathlonResult(ListOfAnaRound);
CyclingResult AnaCResult = new CyclingResult(90,1);
Athlete Ana = new Athlete("Ana",AnaBResult,AnaCResult);
MarathonResult dummyRun = new MarathonResult(55.2, 2);
BiathlonRound Markround1 = new BiathlonRound(5,60);
BiathlonRound Markround2 = new BiathlonRound(4,30);
LinkedList <BiathlonRound> ListOfMarkRound= new LinkedList <BiathlonRound>();
BiathlonResult MarkBResult = new BiathlonResult(ListOfMarkRound);
CyclingResult MarkCResult = new CyclingResult(100,2);
Athlete Mark = new Athlete("Mark",MarkBResult,MarkCResult);
LinkedList <Athlete> ListOfAthletes= new LinkedList <Athlete>();
LinkedList <Athlete> ListOfAthletesR= new LinkedList <Athlete>();
Competition comp1 = new Competition(ListOfAthletes,3);
Competition comp2 = new Competition(ListOfAthletesR,3);
LinkedList <Athlete> ListOfDNF= new LinkedList <Athlete>();
@Test
public void BiathlonDNF(){
	assertTrue(comp1.BiathlonDNF().equals(ListOfDNF));
	assertFalse(comp1.BiathlonDNF().equals(ListOfAthletes));
}

@Test 
public void scoreForAthlete(){
	assertEquals(comp1.scoreForAthlete("Joe"), 590,0);
}

@Test
public void countCyclingImproved(){
	assertEquals(comp1.countCyclingImproved(comp2), 0,0);
}



@Test
public void pointsEarned(){
	assertEquals( JoeBResult.pointsEarned(), 470,0);
	assertEquals( AnaBResult.pointsEarned(), 410,0);
	assertEquals( JoeCResult.pointsEarned(), 120,0);
	assertEquals( AnaCResult.pointsEarned(), 80,0);
	assertEquals( dummyRun.pointsEarned(), 55.2,0);
}

@Test
public void bestRound(){
	assertEquals(JoeBResult.bestRound(), Joeround1);
	assertEquals(AnaBResult.bestRound(), Anaround1);
}	
@Test
public void totalScore(){
	assertEquals(Joe.totalScore(), 590,0);
	assertEquals(Ana.totalScore(), 490,0);
}		
@Test
public void hasBeaten(){
	assertFalse(Joe.hasBeaten(Ana));
	assertTrue(Ana.hasBeaten(Joe));
}	
@Test
public void betterCyclist1(){
	assertEquals(Joe.betterCyclist1(Ana),Ana);
}
@Test
public void betterCyclist2(){
	assertEquals(Joe.betterCyclist2(Ana),Ana);
}
@Test
public void Roundscore(){
	assertEquals(Joeround1.Roundscore(),60,0 );
}
@Test
public void betterscore(){
	assertTrue(AnaCResult.betterscore(JoeCResult) );
	assertFalse(JoeCResult.betterscore(AnaCResult) );
}
}
