
import java.util.LinkedList;
class BMI2 {
  BMI2(){}
 
  public BMISummary bmiReport(LinkedList<PHR> phrs) {
	  LinkedList<String> under = new LinkedList<String>();
	  LinkedList<String>  healthy = new LinkedList<String>();
	  LinkedList<String> over = new LinkedList<String>();
	  LinkedList<String> obese = new LinkedList<String>();
	  BMISummary bmireportreturn = new BMISummary (under,healthy,over,obese);
	  for(int i=0; i < phrs.size(); i++){
		  PHR aphr = phrs.get(i);
		  if(aphr.BMICalc() < 18.5){
			  under.add(aphr.name);
		  }
		  else if((aphr.BMICalc() >= 18.5) && (aphr.BMICalc() < 25)){
			  healthy.add(aphr.name);
		  }
		  else if((aphr.BMICalc() >= 25) && (aphr.BMICalc() < 30)){
			  over.add(aphr.name);
		  }
		  else{
			  obese.add(aphr.name);
		  }
	  }
	  
	  	return bmireportreturn;
  }
}
  
  
