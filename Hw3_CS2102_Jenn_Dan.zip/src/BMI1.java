import java.util.LinkedList;

class BMI1 {
	 BMI1(){} 

	  public double BMI(double weight, double height) {
			 return (weight/(height * height));}  

	
	  public BMISummary bmiReport(LinkedList<PHR> phrs) {
	    LinkedList<String> under = new LinkedList<String>();
	    LinkedList<String> healthy = new LinkedList<String>();
	    LinkedList<String> over = new LinkedList<String>();
	    LinkedList<String> obese = new LinkedList<String>();
	    for (PHR p: phrs) {
	    	if (BMI(p.weight, p.height) < 18.5) {
	    		under.add(p.name); } 
	    	if (18.5 < BMI(p.weight, p.height) && BMI(p.weight, p.height) < 25) {
	    		healthy.add(p.name);}
	    	if ( 25 < BMI(p.weight, p.height) && BMI (p.weight, p.height) <30) {
	    		over.add(p.name);}
	    	if(30 < BMI(p.weight, p.height)){
	    		obese.add(p.name);} }
		return new BMISummary(under, healthy, over, obese); } } 
	  