import java.util.LinkedList;

class DataSmooth2 {
  DataSmooth2(){}
  
  public LinkedList<Double> dataSmooth(LinkedList<PHR> phrs) {
	  LinkedList <Double> heartrate = new LinkedList<Double>();
    for(int i=0; i < phrs.size(); i++){
    	PHR num1 = phrs.get(i);
    	//PHR num2 = phrs.get(i-1);
    	//PHR num3 = phrs.get(i+1);
    	if(i==0){
    		heartrate.add((double) num1.heartRate);
    	}
    	else if((i < phrs.size()-1)&& (i!=0)){
    		heartrate.add( (num1.heartRate + phrs.get(i-1).heartRate + phrs.get(i+1).heartRate) / 3.0);
    	}
    	else{
    		heartrate.add((double) num1.heartRate);
    	}
    }
    return heartrate;
  }
}