import java.util.LinkedList;

class Earthquake2 {
  Earthquake2(){}
      
  // checks whether a datum is a date
  boolean isDate(double anum) { return (int)anum > 10000000; }
  // extracts the month from an 8-digit date
  int extractMonth(double dateNum) { return ((int)dateNum % 10000) / 100; }


  public LinkedList<MaxHzReport> dailyMaxForMonth(LinkedList<Double> data, int month) {
	  LinkedList<MaxHzReport> ListofMax = new LinkedList<MaxHzReport>();
	  double thismonthdata = 0;
	  double maxHz = 0;
	  int monthcount =0;
	  for(int i=0;i<data.size();i++){	
		  if(isDate(data.get(i))){
			  if(month==extractMonth(data.get(i))&&monthcount==0){
			  monthcount++;
			  thismonthdata = data.get(i);
			  maxHz = 0;
			  }
			  else if(month==extractMonth(data.get(i))&&monthcount>0){
				  ListofMax.add(new MaxHzReport(thismonthdata,maxHz));
				  thismonthdata = data.get(i);
				  maxHz = 0;
				  }
			  else{
				  monthcount = 0;
			  }
		  }
		  else if (i==data.size()-1){
			  if(maxHz < data.get(i)){
				  maxHz = data.get(i);
			  }
			  ListofMax.add(new MaxHzReport(thismonthdata,maxHz));
			  
		  }
		  else if (!isDate(data.get(i))){
			  if(maxHz < data.get(i)){
				  maxHz = data.get(i);
				  
			  }
		  }
		  
	  } 
	  return ListofMax;
}
}