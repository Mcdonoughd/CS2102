import java.util.LinkedList;

class Earthquake1 {
  Earthquake1(){}

  // checks whether a datum is a date
  boolean isDate(double anum) { return (int)anum > 10000000; }
  // extracts the month from an 8-digit date
  int extractMonth(double dateNum) { return ((int)dateNum % 10000) / 100; }
    
  public LinkedList<MaxHzReport> AllData(LinkedList<Double> data, int month) {
	  LinkedList<MaxHzReport> ListofMax = new LinkedList<MaxHzReport>();
	  double thismonthdata = 0;
	  double maxHz = 0;
	  for(int i=0;i<data.size();i++){	
		  if(isDate(data.get(i))){
			  ListofMax.add(new MaxHzReport(thismonthdata,maxHz));
			  thismonthdata = data.get(i);
			  maxHz = 0;
			  
		  }
		  else if (i==data.size()-1){
			  if(maxHz < data.get(i)){
				  maxHz = data.get(i);
			  }
			  ListofMax.add(new MaxHzReport(thismonthdata,maxHz));
		  }
		  else if (!isDate(data.get(i))){
			  if(maxHz < data.get(i)){
				  maxHz = data.get(i);
				 
			  }
		  }
		  
	  } 
	  return ListofMax;
  
  }

 
  public LinkedList<MaxHzReport> dailyMaxForMonth(LinkedList<Double> data, int month) {
	  LinkedList<MaxHzReport> ListofMaxMonth = new LinkedList<MaxHzReport>();
	  LinkedList<MaxHzReport> ListofallMax = AllData(data,month);
	  for(int i =0; i < ListofallMax.size(); i++){
		  if(extractMonth(ListofallMax.get(i).date) == month){
			  ListofMaxMonth.add(ListofallMax.get(i));
		  }
	  }
	 return ListofMaxMonth;
}
}

